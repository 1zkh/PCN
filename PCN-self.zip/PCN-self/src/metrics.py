
import torch
from torch import Tensor
import torch.nn.functional as F

def mse(y_true, y_pred):
    return F.mse_loss(y_true, y_pred, reduction='mean')

def rmse(y_true, y_pred):
    return torch.sqrt(F.mse_loss(y_true, y_pred, reduction='mean'))

def mae(y_true, y_pred):
    return F.l1_loss(y_true, y_pred, reduction='mean')

def r2_score(y_true, y_pred):
    from sklearn.metrics import r2_score
    return r2_score(y_true, y_pred)

# def mape(y_true, y_pred):
#     from sklearn.metrics import mean_absolute_percentage_error
#     return mean_absolute_percentage_error(y_true, y_pred)
def mape(y_true, y_pred):
    """
    计算 MAPE（平均绝对百分比误差）

    参数:
    y_true (torch.Tensor): 真实值
    y_pred (torch.Tensor): 预测值

    返回:
    torch.Tensor: MAPE 值
    """
    # 确保 y_true 和 y_pred 的形状相同
    assert y_true.shape == y_pred.shape, "真实值和预测值的形状必须相同"

    # 避免除以零的情况，通常加一个很小的数（如 1e-9）
    y_true = y_true.float()
    y_pred = y_pred.float()
    epsilon = 1e-9

    # 计算 MAPE
    mape_value = torch.mean(torch.abs((y_true - y_pred) / (y_true + epsilon)))
    return mape_value
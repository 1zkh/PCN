__all__ = ['PCN']

# Cell
from typing import Callable, Optional
import torch
from torch import nn
from torch import Tensor
import torch.nn.functional as F
import numpy as np

from collections import OrderedDict
from ..models.layers.pos_encoding import *
from ..models.layers.basics import *
from ..models.layers.attention import *





class ContrastiveLoss(nn.Module):
    def __init__(self, lambda_param=0.05):
        super(ContrastiveLoss, self).__init__()
        self.lambda_param = lambda_param

    def forward(self, features1, features2):
        # assert features1.shape == features2.shape, "Two input tensors must have the same shape."
        B, P, S, W = features1.shape

        # 展平成二维张量 (B * P * W, S)
        z1 = features1.permute(0, 1, 3, 2).reshape(B * P,  W*S)  # (B*P*W, S)
        z2 = features2.permute(0, 1, 3, 2).reshape(B * P , W*S)  # (B*P*W, S)

        q = F.normalize(z1, p=2, dim=1)  # L2 normalize along embedding dimension
        k = F.normalize(z2, p=2, dim=1)
        # Compute the cross-correlation matrix
        C = torch.matmul(q, k.t())  # Shape: (B * P, B * P)
        logits = C / self.lambda_param
        # 构建labels（每个样本自己的索引）
        labels = torch.arange(q.size(0), device=q.device)  # [0, 1, 2, ..., batch_size-1]
        # 计算交叉熵损失
        loss = F.cross_entropy(logits, labels)
        return loss




def getchannel(a):
    n = 1
    while 2*(2**n-1)+1 < a:
        n = n+1
    print("cn number:")
    print(n)#2(2”-1)+1
    return n

def getchannel1(a):
    n = 1 #n*(2-1)+n*(n-1)//2+1
    while n*(n-1) + 1 < a:
        n = n+1
    print("cn number:")
    print(n)
    return n


def approx_infoNCE_loss(q, k, tau=0.07):
    # 调整张量形状以进行相似度计算
    q = q.reshape(q.size(0), -1)  # [batch_size, num_channels * height * width]
    k = k.reshape(k.size(0), -1)  # [batch_size, num_channels * height * width]

    # 计算query和key的相似度得分
    similarity_scores = torch.matmul(q, k.t())  # 矩阵乘法计算相似度得分
    # 计算Logits
    logits = similarity_scores / tau
    # 构建labels（每个样本自己的索引）
    labels = torch.arange(q.size(0), device=q.device)  # [0, 1, 2, ..., batch_size-1]
    # 计算交叉熵损失
    loss = F.cross_entropy(logits, labels)
    return loss

def _loss(preds, target):
    tensor = torch.zeros(preds.size(0), preds.size(1), preds.size(2)).cuda()
    half_num = preds.size(1) // 2
    tensor[:, half_num:, :] = 1
    mask = tensor.bool().cuda()
    loss = (preds - target) ** 2
    loss = loss.mean(dim=-1)
    loss = (loss * mask).sum() / mask.sum()
    return loss

class CustomLoss(nn.Module):
    def __init__(self, param_init=0.5):
        super(CustomLoss, self).__init__()
        # 初始化一个可学习的参数
        self.param = nn.Parameter(torch.tensor(param_init))
        self.cosloss = CosineSimilarityLoss()
    def forward(self, inputs, targets):
        # 计算损失
        param_clamp = torch.sigmoid(self.param)
        loss = approx_infoNCE_loss(inputs, targets) * param_clamp
        return loss

class CosineSimilarityLoss(nn.Module):
    def __init__(self):
        super(CosineSimilarityLoss, self).__init__()

    def forward(self, tensor_a, tensor_b):
        # 计算两个张量的余弦相似度
        cosine_sim = F.cosine_similarity(tensor_a, tensor_b, dim=-1)

        # 计算损失，鼓励余弦相似度增加
        loss = 1 - cosine_sim

        # 返回损失的均值
        return loss.mean()


# Cell
class PCN(nn.Module):
    """
    Output dimension:
         [bs x target_dim x nvars] for prediction
         [bs x target_dim] for regression
         [bs x target_dim] for classification
         [bs x num_patch x n_vars x patch_len] for pretrain
    """

    def __init__(self, c_in: int, target_dim: int, patch_len: int, stride: int, num_patch: int,
                 n_layers: int = 3, d_model=128, n_heads=16, shared_embedding=True, d_ff: int = 256,
                 norm: str = 'BatchNorm', attn_dropout: float = 0., dropout: float = 0., act: str = "gelu",
                 res_attention: bool = True, pre_norm: bool = False, store_attn: bool = False,
                 pe: str = 'zeros', learn_pe: bool = True, head_dropout=0,
                 head_type="prediction", individual=False,
                 y_range: Optional[tuple] = None, verbose: bool = False, **kwargs):

        super().__init__()

        assert head_type in ['pretrain', 'prediction'], 'head type should be either pretrain, prediction'
        # Backbone
        self.backbone = Encoder(c_in, num_patch=num_patch, patch_len=patch_len,
                                        n_layers=n_layers, d_model=d_model, n_heads=n_heads,
                                        shared_embedding=shared_embedding, d_ff=d_ff,
                                        attn_dropout=attn_dropout, dropout=dropout, act=act,
                                        res_attention=res_attention, pre_norm=pre_norm, store_attn=store_attn,
                                        pe=pe, learn_pe=learn_pe, verbose=verbose, **kwargs)

        # Head
        self.n_vars = c_in
        self.head_type = head_type

        if head_type == "pretrain":
            self.pretrainhead = PretrainHead(d_model, patch_len,
                                     head_dropout)  # custom head passed as a partial func with all its kwargs
        elif head_type == "prediction":
            self.predictionhead = PredictionHead(individual, self.n_vars, d_model, num_patch, target_dim, head_dropout)
        elif head_type == "regression":
            self.head = RegressionHead(self.n_vars, d_model, target_dim, head_dropout, y_range)
        elif head_type == "classification":
            self.head = ClassificationHead(self.n_vars, d_model, target_dim, head_dropout)

        self.SimilarityLoss = ContrastiveLoss(0.07)
        # self.dtw_loss_fn = NonNegativeDTWLoss(gamma=0.1)
    def forward(self, z1, z2, z3):
        """
        z: tensor [bs x num_patch x n_vars x patch_len]
        """
        if self.head_type == "pretrain":
            z4 = z1 + z3
            z1 = self.backbone(z1)  # z: [bs x nvars x d_model x num_patch]
            z2 = self.backbone(z2) #CM

            similarityLoss = self.SimilarityLoss(z1,z2)#approx_infoNCE_loss(z1,z2)#self.dtw_loss_fn(z1,z2)#approx_infoNCE_loss(z1,z2)#self.SimilarityLoss(z1,z2)

            z1 = self.pretrainhead(z1)
            z2 = self.pretrainhead(z2)
            # loss_mse1 = F.mse_loss(z1, z4)

            loss_mse2 = _loss(z2, z4)
            return z1, similarityLoss + loss_mse2
        elif self.head_type == "prediction":
            z1 = self.backbone(z1)
            z1 = self.predictionhead(z1)
            a = 0
            return z1,a


class RegressionHead(nn.Module):
    def __init__(self, n_vars, d_model, output_dim, head_dropout, y_range=None):
        super().__init__()
        self.y_range = y_range
        self.flatten = nn.Flatten(start_dim=1)
        self.dropout = nn.Dropout(head_dropout)
        self.linear = nn.Linear(n_vars * d_model, output_dim)

    def forward(self, x):
        """
        x: [bs x nvars x d_model x num_patch]
        output: [bs x output_dim]
        """
        x = x[:, :, :, -1]  # only consider the last item in the sequence, x: bs x nvars x d_model
        x = self.flatten(x)  # x: bs x nvars * d_model
        x = self.dropout(x)
        y = self.linear(x)  # y: bs x output_dim
        if self.y_range: y = SigmoidRange(*self.y_range)(y)
        return y


class ClassificationHead(nn.Module):
    def __init__(self, n_vars, d_model, n_classes, head_dropout):
        super().__init__()
        self.flatten = nn.Flatten(start_dim=1)
        self.dropout = nn.Dropout(head_dropout)
        self.linear = nn.Linear(n_vars * d_model, n_classes)

    def forward(self, x):
        """
        x: [bs x nvars x d_model x num_patch]
        output: [bs x n_classes]
        """
        x = x[:, :, :, -1]  # only consider the last item in the sequence, x: bs x nvars x d_model
        x = self.flatten(x)  # x: bs x nvars * d_model
        x = self.dropout(x)
        y = self.linear(x)  # y: bs x n_classes
        return y


class PredictionHead(nn.Module):
    def __init__(self, individual, n_vars, d_model, num_patch, forecast_len, head_dropout=0, flatten=False):
        super().__init__()

        self.individual = individual
        self.n_vars = n_vars
        self.flatten = flatten
        head_dim = d_model * num_patch

        if self.individual:
            self.linears = nn.ModuleList()
            self.dropouts = nn.ModuleList()
            self.flattens = nn.ModuleList()
            for i in range(self.n_vars):
                self.flattens.append(nn.Flatten(start_dim=-2))
                self.linears.append(nn.Linear(head_dim, forecast_len))
                self.dropouts.append(nn.Dropout(head_dropout))
        else:
            self.flatten = nn.Flatten(start_dim=-2)
            self.linear = nn.Linear(head_dim, forecast_len)
            self.dropout = nn.Dropout(head_dropout)

    def forward(self, x):
        """
        x: [bs x nvars x d_model x num_patch]
        output: [bs x forecast_len x nvars]
        """
        if self.individual:
            x_out = []
            for i in range(self.n_vars):
                z = self.flattens[i](x[:, i, :, :])  # z: [bs x d_model * num_patch]
                z = self.linears[i](z)  # z: [bs x forecast_len]
                z = self.dropouts[i](z)
                x_out.append(z)
            x = torch.stack(x_out, dim=1)  # x: [bs x nvars x forecast_len]
        else:
            x = self.flatten(x)  # x: [bs x nvars x (d_model * num_patch)]
            x = self.dropout(x)
            x = self.linear(x)  # x: [bs x nvars x forecast_len]
        return x.transpose(2, 1)  # [bs x forecast_len x nvars]


class PretrainHead(nn.Module):
    def __init__(self, d_model, patch_len, dropout):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(d_model, patch_len)

    def forward(self, x):
        """
        x: tensor [bs x nvars x d_model x num_patch]
        output: tensor [bs x nvars x num_patch x patch_len]
        """

        x = x.transpose(2, 3)  # [bs x nvars x num_patch x d_model]
        x = self.linear(self.dropout(x))  # [bs x nvars x num_patch x patch_len]
        x = x.permute(0, 2, 1, 3)  # [bs x num_patch x nvars x patch_len]
        return x


class Encoder(nn.Module):
    def __init__(self, c_in, num_patch, patch_len,
                 n_layers=3, d_model=128, n_heads=16, shared_embedding=True,
                 d_ff=256, norm='BatchNorm', attn_dropout=0., dropout=0., act="gelu", store_attn=False,
                 res_attention=True, pre_norm=False,
                 pe='zeros', learn_pe=True, verbose=False, **kwargs):

        super().__init__()
        self.n_vars = c_in
        self.num_patch = num_patch
        self.patch_len = patch_len
        self.d_model = d_model
        self.shared_embedding = shared_embedding

        # Input encoding: projection of feature vectors onto a d-dim vector space
        if not shared_embedding:
            self.W_P = nn.ModuleList()
            for _ in range(self.n_vars): self.W_P.append(nn.Linear(patch_len, d_model))
        else:
            self.W_P = nn.Linear(patch_len, d_model)

            # Positional encoding
        self.W_pos = positional_encoding(pe, learn_pe, num_patch, patch_len)

        # Residual dropout
        self.dropout = nn.Dropout(dropout)

        # Encoder
        self.encoder = CNEncoder(d_model, self.num_patch, self.patch_len,d_ff=d_ff, norm=norm, attn_dropout=attn_dropout, dropout=dropout,
                                  pre_norm=pre_norm, activation=act, res_attention=res_attention, n_layers=n_layers,
                                  store_attn=store_attn)

    def forward(self, x) -> Tensor:
        """
        x: tensor [bs x num_patch x nvars x patch_len]
        """
        bs, num_patch, n_vars, patch_len = x.shape
        # Input encoding
        # if not self.shared_embedding:
        #     x_out = []
        #     for i in range(n_vars):
        #         z = self.W_P[i](x[:, :, i, :])
        #         x_out.append(z)
        #     x = torch.stack(x_out, dim=2)
        # else:
        #     x = self.W_P(x)  # x: [bs x num_patch x nvars x d_model]
        x = x.transpose(1, 2)  # x: [bs x nvars x num_patch x d_model] [bs x nvars x num_patch x patch_len]

        u = torch.reshape(x, (bs * n_vars, num_patch, self.patch_len))  # u: [bs * nvars x num_patch x d_model]
        u = self.dropout(u + self.W_pos)  # u: [bs * nvars x num_patch x d_model]

        # Encoder
        z = self.encoder(u)  # z: [bs * nvars x num_patch x d_model]
        z = torch.reshape(z, (-1, n_vars, num_patch, self.d_model))  # z: [bs x nvars x num_patch x d_model]
        z = z.permute(0, 1, 3, 2)  # z: [bs x nvars x d_model x num_patch]

        return z


class TemporalBlock(nn.Module):
    def __init__(self, n_inputs, n_outputs, kernel_size, stride, dilation, padding, dropout=0.1):
        super(TemporalBlock, self).__init__()
        self.conv1 = nn.Conv1d(n_inputs, n_outputs, kernel_size,stride=stride, padding=padding, dilation=dilation)#weight_norm()
        self.dropout1 = nn.Dropout(dropout)
        self.gelu = nn.GELU()
        self.net = nn.Sequential(self.conv1,self.gelu,self.dropout1) #, self.chomp1, self.relu1, self.dropout1 ,self.gelu,
        # self.net = nn.Sequential(self.conv1, self.dropout1)
        self.init_weights()
        self.n_inputs = n_inputs
        self.n_outputs = n_outputs


    def init_weights(self):
        self.conv1.weight.data.normal_(0, 0.01)
    def forward(self, x):
        out = self.net(x)
        if self.n_inputs == self.n_outputs:
            out = out + x
        return out





# Cell
class CNEncoder(nn.Module):
    def __init__(self, d_model, patch_num, patch_len,d_ff=None,
                 norm='BatchNorm', attn_dropout=0., dropout=0., activation='gelu',
                 res_attention=False, n_layers=1, pre_norm=False, store_attn=False):
        super().__init__()
        self.patch_num = patch_num

        self.d_model = d_model
        self.patch_len = patch_len
        layerD = []
        cn = 2# 1 2 3!!!!!!!!!!!!!!!!!!!!!!!!!!!

        if cn == 1:
            self.num_levelk = getchannel1(self.patch_num)
            kernel_size = 3
            for i in range(self.num_levelk):
                if i == 0:
                    in_channels = self.patch_len
                else:
                    in_channels = self.d_model  # self.window_size if i == 0 else
                out_channels = self.d_model
                layerD += [TemporalBlock(in_channels, out_channels, kernel_size=kernel_size, stride=1, dilation=1,
                                         padding=int((kernel_size - 1) / 2), dropout=0.2)]
                kernel_size = kernel_size + 2
        elif cn == 2:
            self.num_levels = getchannel(self.patch_num)
            for i in range(self.num_levels):
                if i == 0:
                    in_channels = self.patch_len
                else:
                    in_channels = self.d_model
                # in_channels = self.d_model  # self.window_size if i == 0 else
                out_channels = self.d_model
                # kernel_size = int(2 * i + 1)
                kernel_size = 5
                dilation = 2 ** i
                # print((dilation*(kernel_size-1))/2)
                layerD += [TemporalBlock(in_channels, out_channels, kernel_size=kernel_size, stride=1, dilation=dilation,
                                         padding=int(dilation*(kernel_size-1)/2), dropout=0.1)]
        elif cn == 3:
            if self.patch_num %2 != 0:
                kernel_size = self.patch_num
            else:
                kernel_size = self.patch_num+1
            level = 1
            for i in range(level):
                if i == 0:
                    in_channels = self.patch_len
                else:
                    in_channels = self.d_model
                # in_channels = self.d_model  # self.window_size if i == 0 else
                out_channels = self.d_model
                # kernel_size = int(2 * i + 1)
                layerD += [TemporalBlock(in_channels, out_channels, kernel_size=kernel_size, stride=1, dilation=1,
                                         padding=(kernel_size - 1) // 2, dropout=0.2)]
            k = 7
            layerD += [TemporalBlock(n_inputs=self.d_model, n_outputs=self.d_model, kernel_size=k, stride=1, dilation=1,
                                     padding=(k - 1) // 2, dropout=0.2)]
        self.networkD = nn.Sequential(*layerD)
    def forward(self, src: Tensor):
        """
        src: tensor [bs x q_len x d_model]
        """
        x = src.permute(0, 2, 1)
        x = self.networkD(x)
        x = x.permute(0, 2, 1)
        return x



#